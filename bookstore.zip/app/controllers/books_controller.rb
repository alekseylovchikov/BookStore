class BooksController < ApplicationController
  def new
    @page_title = 'Add New Book'

    @book = Book.new
  end

  def create
    @book = Book.new
    @book.save

    redirect_to books_path
  end

  def update
  end

  def edit
  end

  def destroy
  end

  def index
  end

  def show
  end

  private
  def book_params
    params.require(:book).permit(:title, :category_id, :author_id, :publisher_id, :price, :buy, :info, :pages, :year)
  end
end
