class Publisher < ActiveRecord::Base
	has_many :book
end
